﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Mid_Term_Project
{
    public class Player
    {
        public string name = "";
        public int gold = 5;
        public int stamina = 10;
        public int health = 5;
        public int invitorySpace = 5;
    }
}
